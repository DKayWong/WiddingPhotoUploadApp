require('dotenv').config();
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { google } = require('googleapis');

const app = express();
const upload = multer({ dest: 'uploads/' });
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));

const auth = new google.auth.GoogleAuth({
  keyFile: 'service-account.json',
  scopes: ['https://www.googleapis.com/auth/drive'],
});
const driveService = google.drive({ version: 'v3', auth });

async function createOrGetFolder(name) {
  const q = `name='${name}' and mimeType='application/vnd.google-apps.folder' and trashed=false`;
  const res = await driveService.files.list({
    q,
    fields: 'files(id, name)',
  });
  if (res.data.files.length > 0) return res.data.files[0].id;

  const fileMetadata = {
    name,
    mimeType: 'application/vnd.google-apps.folder',
  };
  const folder = await driveService.files.create({
    resource: fileMetadata,
    fields: 'id',
  });
  return folder.data.id;
}

async function uploadFile(filePath, filename, folderId) {
  const fileMetadata = {
    name: filename,
    parents: [folderId],
  };
  const media = {
    mimeType: 'image/jpeg',
    body: fs.createReadStream(filePath),
  };
  const file = await driveService.files.create({
    resource: fileMetadata,
    media,
    fields: 'id',
  });
  return file.data.id;
}

async function listImageFiles(folderId) {
  const res = await driveService.files.list({
    q: `'${folderId}' in parents and mimeType contains 'image/' and trashed=false`,
    fields: 'files(id, name, webViewLink, thumbnailLink)',
  });
  return res.data.files;
}

app.post('/upload', upload.array('photos', 10), async (req, res) => {
  const name = req.body.name;
  const files = req.files;

  if (!name || !files || files.length === 0) {
    console.warn('⚠️ 使用者未提供姓名或檔案');
    return res.status(400).json({ success: false, message: '請提供姓名與照片' });
  }

  try {
    const folderId = await createOrGetFolder(name);
    console.log(`📁 使用者「${name}」的資料夾 ID：${folderId}`);

    const uploadPromises = files.map(file => {
      return uploadFile(file.path, file.originalname, folderId)
        .then(fileId => {
          fs.unlinkSync(file.path);
          return fileId;
        })
        .catch(err => {
          console.error(`❌ 上傳失敗：${file.originalname}`, err);
          return null;
        });
    });

    await Promise.all(uploadPromises);

    const images = await listImageFiles(folderId);
    console.log(`✅ 成功上傳 ${images.length} 張圖片`);

    res.json({ success: true, name, images });
  } catch (err) {
    console.error('🚨 全域錯誤:', err);
    res.status(500).json({ success: false, message: '伺服器錯誤，請稍後再試' });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
});
